import TableData from './table';

function App() {
return (
	<div className="App">
	<h1>Hello Geeks!!!</h1>
	<TableData />
	</div>
);
}

export default App;
